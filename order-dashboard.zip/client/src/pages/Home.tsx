import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card } from '@/components/ui/card';
import { TrendingUp, Users, ShoppingCart, DollarSign } from 'lucide-react';

/**
 * Data-Forward Minimalism Design System
 * - Teal accent (#0891b2) for key metrics
 * - Charcoal text (#1a1a1a) on off-white background (#fafafa)
 * - Generous whitespace and clear typography hierarchy
 * - Asymmetric layout guiding eye through information
 */

export default function Home() {
  // Analysis data from customer orders
  const metrics = {
    totalSales: 256607,
    totalOrders: 1000,
    avgOrderValue: 256.61,
    topCountry: 'Kenya'
  };

  // Country sales data
  const countrySalesData = [
    { name: 'Kenya', value: 90563 },
    { name: 'Ghana', value: 85892 },
    { name: 'Nigeria', value: 80152 }
  ];

  // Product popularity data
  const productData = [
    { name: 'Earpods', quantity: 421 },
    { name: 'Laptop', quantity: 420 },
    { name: 'Tablet', quantity: 412 },
    { name: 'Phone', quantity: 402 },
    { name: 'Charger', quantity: 334 }
  ];

  // Daily sales trend
  const dailySalesData = [
    { day: '10', sales: 18705 },
    { day: '11', sales: 15392 },
    { day: '12', sales: 18525 },
    { day: '13', sales: 14356 },
    { day: '14', sales: 19289 },
    { day: '15', sales: 16648 },
    { day: '16', sales: 15061 },
    { day: '17', sales: 15113 },
    { day: '18', sales: 16645 },
    { day: '19', sales: 13864 },
    { day: '20', sales: 13708 },
    { day: '21', sales: 14588 },
    { day: '22', sales: 17698 },
    { day: '23', sales: 16540 },
    { day: '24', sales: 15834 },
    { day: '25', sales: 14641 }
  ];

  // Payment method preference
  const paymentData = [
    { name: 'Bank', value: 340 },
    { name: 'Cash', value: 335 },
    { name: 'Card', value: 325 }
  ];

  // Top customers
  const topCustomers = [
    { name: 'John Doe', amount: 33229 },
    { name: 'Aliyu Musa', amount: 27650 },
    { name: 'Jenny Ade', amount: 26641 },
    { name: 'Kelvin Musa', amount: 26306 },
    { name: 'Samuel Tobi', amount: 26212 }
  ];

  const COLORS = ['#0891b2', '#06b6d4', '#1a1a1a', '#475569', '#cbd5e1'];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section with Background Image */}
      <div className="relative overflow-hidden bg-gradient-to-br from-background via-background to-secondary/20 pt-12 pb-20">
        <div className="absolute inset-0 opacity-10">
          <img 
            src="https://d2xsxph8kpxj0f.cloudfront.net/310519663433488626/ZfiHPp54BseEyXjCKNAe2n/hero-background-NQSYZVJ5eqvK3orN9ypEwp.webp"
            alt="background"
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="container relative z-10">
          <div className="max-w-2xl">
            <h1 className="text-5xl font-bold text-foreground mb-3" style={{ fontFamily: 'Geist, sans-serif' }}>
              Customer Orders
            </h1>
            <h2 className="text-3xl font-bold text-primary mb-4" style={{ fontFamily: 'Geist, sans-serif' }}>
              Analytics Dashboard
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed max-w-xl">
              Explore data more intuitively. Understand trends better. Easily save or share insights from 1,000 customer orders across three African markets.
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-12">
        {/* Key Metrics Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {/* Total Sales Metric */}
          <Card className="bg-white border border-border p-6 hover:shadow-lg transition-shadow duration-200">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2" style={{ fontFamily: 'IBM Plex Mono, monospace' }}>
                  TOTAL SALES
                </p>
                <p className="text-3xl font-bold text-foreground" style={{ fontFamily: 'IBM Plex Mono, monospace' }}>
                  ${(metrics.totalSales / 1000).toFixed(1)}K
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-primary" strokeWidth={1.5} />
            </div>
          </Card>

          {/* Total Orders Metric */}
          <Card className="bg-white border border-border p-6 hover:shadow-lg transition-shadow duration-200">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2" style={{ fontFamily: 'IBM Plex Mono, monospace' }}>
                  TOTAL ORDERS
                </p>
                <p className="text-3xl font-bold text-foreground" style={{ fontFamily: 'IBM Plex Mono, monospace' }}>
                  {metrics.totalOrders.toLocaleString()}
                </p>
              </div>
              <ShoppingCart className="w-8 h-8 text-primary" strokeWidth={1.5} />
            </div>
          </Card>

          {/* Average Order Value */}
          <Card className="bg-white border border-border p-6 hover:shadow-lg transition-shadow duration-200">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2" style={{ fontFamily: 'IBM Plex Mono, monospace' }}>
                  AVG ORDER VALUE
                </p>
                <p className="text-3xl font-bold text-foreground" style={{ fontFamily: 'IBM Plex Mono, monospace' }}>
                  ${metrics.avgOrderValue.toFixed(2)}
                </p>
              </div>
              <TrendingUp className="w-8 h-8 text-primary" strokeWidth={1.5} />
            </div>
          </Card>

          {/* Top Country */}
          <Card className="bg-white border border-border p-6 hover:shadow-lg transition-shadow duration-200">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2" style={{ fontFamily: 'IBM Plex Mono, monospace' }}>
                  TOP COUNTRY
                </p>
                <p className="text-3xl font-bold text-foreground" style={{ fontFamily: 'IBM Plex Mono, monospace' }}>
                  {metrics.topCountry}
                </p>
              </div>
              <Users className="w-8 h-8 text-primary" strokeWidth={1.5} />
            </div>
          </Card>
        </div>

        {/* Charts Section */}
        <div className="space-y-12">
          {/* Why Question 1: Sales by Country */}
          <div className="bg-white border border-border rounded-lg p-8">
            <div className="mb-8">
              <h3 className="text-2xl font-bold text-foreground mb-2" style={{ fontFamily: 'Geist, sans-serif' }}>
                Why do some countries have higher sales?
              </h3>
              <p className="text-muted-foreground">
                Kenya leads with $90,563 in total sales, followed by Ghana and Nigeria. Geographic distribution shows balanced market penetration across the region.
              </p>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={countrySalesData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e5e5" />
                <XAxis dataKey="name" stroke="#1a1a1a" />
                <YAxis stroke="#1a1a1a" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#ffffff', border: '1px solid #e5e5e5' }}
                  formatter={(value) => `$${value.toLocaleString()}`}
                />
                <Bar dataKey="value" fill="#0891b2" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Why Question 2: Product Popularity */}
          <div className="bg-white border border-border rounded-lg p-8">
            <div className="mb-8">
              <h3 className="text-2xl font-bold text-foreground mb-2" style={{ fontFamily: 'Geist, sans-serif' }}>
                Why are certain products more popular?
              </h3>
              <p className="text-muted-foreground">
                Earpods and Laptops dominate with 421 and 420 units sold respectively. Electronics show strong demand, with Chargers being the least popular at 334 units.
              </p>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={productData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e5e5" />
                <XAxis type="number" stroke="#1a1a1a" />
                <YAxis dataKey="name" type="category" stroke="#1a1a1a" width={80} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#ffffff', border: '1px solid #e5e5e5' }}
                  formatter={(value) => `${value} units`}
                />
                <Bar dataKey="quantity" fill="#06b6d4" radius={[0, 8, 8, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Why Question 3: Daily Sales Trend */}
          <div className="bg-white border border-border rounded-lg p-8">
            <div className="mb-8">
              <h3 className="text-2xl font-bold text-foreground mb-2" style={{ fontFamily: 'Geist, sans-serif' }}>
                Why does sales volume fluctuate over time?
              </h3>
              <p className="text-muted-foreground">
                Sales peak on day 14 ($19,289) and show cyclical patterns. Mid-month days (14-15) demonstrate higher customer activity, while end-of-month shows decline.
              </p>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={dailySalesData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e5e5" />
                <XAxis dataKey="day" stroke="#1a1a1a" />
                <YAxis stroke="#1a1a1a" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#ffffff', border: '1px solid #e5e5e5' }}
                  formatter={(value) => `$${value.toLocaleString()}`}
                />
                <Line 
                  type="monotone" 
                  dataKey="sales" 
                  stroke="#0891b2" 
                  dot={false}
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Why Question 4: Payment Methods */}
          <div className="bg-white border border-border rounded-lg p-8">
            <div className="mb-8">
              <h3 className="text-2xl font-bold text-foreground mb-2" style={{ fontFamily: 'Geist, sans-serif' }}>
                Why do customers choose specific payment methods?
              </h3>
              <p className="text-muted-foreground">
                Bank transfers lead with 340 transactions, closely followed by Cash (335) and Card payments (325). Customers show balanced preference across all payment channels.
              </p>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={paymentData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={100}
                  fill="#0891b2"
                  dataKey="value"
                >
                  {paymentData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => `${value} transactions`} />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Why Question 5: Top Customers */}
          <div className="bg-white border border-border rounded-lg p-8">
            <div className="mb-8">
              <h3 className="text-2xl font-bold text-foreground mb-2" style={{ fontFamily: 'Geist, sans-serif' }}>
                Why are some customers more valuable?
              </h3>
              <p className="text-muted-foreground">
                John Doe is the top customer with $33,229 in lifetime value. The top 5 customers represent significant revenue concentration, indicating strong customer loyalty and repeat purchases.
              </p>
            </div>
            <div className="space-y-3">
              {topCustomers.map((customer, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-background rounded border border-border">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold">
                      {index + 1}
                    </div>
                    <span className="font-medium text-foreground">{customer.name}</span>
                  </div>
                  <span className="font-mono text-primary font-semibold">
                    ${customer.amount.toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Section */}
        <div className="mt-16 pt-8 border-t border-border">
          <p className="text-center text-muted-foreground text-sm">
            Dashboard built with customer order data analysis. Explore data more intuitively, understand trends better, and easily save or share insights.
          </p>
        </div>
      </div>
    </div>
  );
}
